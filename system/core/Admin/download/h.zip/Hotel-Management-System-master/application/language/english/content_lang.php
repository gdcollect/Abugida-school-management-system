<?php

    $lang['site_title'] = "سامانه مدیریت هتل";
    /*------------------------------------------------------*/
    $lang['New CheckIn'] = "New CheckIn";
    $lang['Full Date'] = "Full Date";
    $lang['View Full list'] = "View Full list";
    $lang['View Details'] = "View Details";
    
    $lang['Customer'] = "Customer";
    $lang['Today Check-Out !'] = "Today Check-Out !";
    $lang['Today Check-In'] = "Today Check-In";
    $lang['System'] = "System";
    $lang['Config Wizard'] = "Config Wizard";
    $lang['Checkout'] = "Checkout";
    $lang['Checkin'] = "Checkin";
    $lang['Reservation'] = "Reservation";
    $lang['User Profile'] = "User Profile";
    $lang['Setting'] = "Setting";
    $lang['Logout'] = "Logout";

    
    
    







    ?>