<?php $this->load->view('member/header'); ?>

<?php $this->load->view($main_content); ?>

<?php $this->load->view('member/footer'); ?>