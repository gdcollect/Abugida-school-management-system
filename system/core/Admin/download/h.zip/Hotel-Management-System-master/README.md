Hotel Management System (HMS) developed for managing small hotel's or guess house in Web Base and written in PHP with admin panel and customer dashboard

PHP 5.1.6 or newer</br>
Mysql</br>
Codeignither 2.1.2</br>
Bootstrap 3.0</br>
jquery 1.7</br>



<h2>What HMS can do ? :</h2>
<ul>
  <li>Administration dashboard , Customer dashboard</li>
  <li>Admin Login,Customer signup & login</li> 
  <li>Booking,Checkin,Checkout</li>
  <li>Rooms , Room types</li>
  <li>Report , user validation</li>
  <li>more ....</li>
</ul>

### Screenshot
Customer Dashboard:
![hotel management system](https://cloud.githubusercontent.com/assets/6250203/20296819/2d7731f6-ab22-11e6-9863-d485b39c5e17.png)
![hotel management system-1](https://cloud.githubusercontent.com/assets/6250203/20296829/407c3698-ab22-11e6-869c-ec82d992320b.png)

Admin Dashboard:
![selection_034](https://cloud.githubusercontent.com/assets/6250203/9320485/0b92a0e8-4570-11e5-8d75-9ec4e365939e.png)
![hotel management system-2](https://cloud.githubusercontent.com/assets/6250203/20296838/4b6868ce-ab22-11e6-85bb-3bc118658c23.png)
![hotel management system-3](https://cloud.githubusercontent.com/assets/6250203/20296849/5b46792a-ab22-11e6-9f57-1793d3276e1c.png)
![hotel management system-4](https://cloud.githubusercontent.com/assets/6250203/20296852/65c41a9c-ab22-11e6-84a0-e31ecc9e7a2f.png)

